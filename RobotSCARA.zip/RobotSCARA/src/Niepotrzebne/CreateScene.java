/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Niepotrzebne;

import com.sun.j3d.utils.geometry.Sphere;
import com.sun.j3d.utils.image.TextureLoader;
import javax.media.j3d.AmbientLight;
import javax.media.j3d.Appearance;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.DirectionalLight;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.Texture;
import javax.media.j3d.Texture2D;
import javax.vecmath.Color3f;
import javax.vecmath.Vector3f;

/**
 *
 * @author Michał
 */
public class CreateScene extends BranchGroup {
    
    public BranchGroup createScene()
    {
        BranchGroup nodeOfScene = new BranchGroup();
        
        Appearance appearanceOfSky = new Appearance();
        Appearance appearanceOfFloor = new Appearance();
        
        TextureLoader loader = new TextureLoader("images/Floor.jpg",null);
        ImageComponent2D image = loader.getImage();
        
        Texture2D imageOfFloor = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA,
                                        image.getWidth(), image.getHeight());

        imageOfFloor.setImage(0, image);
        imageOfFloor.setBoundaryModeS(Texture.WRAP);
        imageOfFloor.setBoundaryModeT(Texture.WRAP);
        
        loader = new TextureLoader("images/WhiteImage.jpg",null);
        image = loader.getImage();

        Texture2D imageOfSky = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA,
                                        image.getWidth(), image.getHeight());
        imageOfSky.setImage(0, image);
        imageOfSky.setBoundaryModeS(Texture.WRAP);
        imageOfSky.setBoundaryModeT(Texture.WRAP);
        
        BoundingSphere bounds = new BoundingSphere();
        AmbientLight lightA = new AmbientLight();
        lightA.setInfluencingBounds(bounds);
        nodeOfScene.addChild(lightA);
        
        DirectionalLight lightD = new DirectionalLight();
        lightD.setInfluencingBounds(bounds);
        lightD.setDirection(new Vector3f(0.0f, 0.0f, -1.0f));
        lightD.setColor(new Color3f(1.0f, 1.0f, 1.0f));
        nodeOfScene.addChild(lightD);
        
        appearanceOfSky.setTexture(imageOfSky);
        appearanceOfFloor.setTexture(imageOfFloor);
        
        Sphere kula = new Sphere(3f, Sphere.GENERATE_NORMALS_INWARD| Sphere.GENERATE_TEXTURE_COORDS, appearanceOfSky);
        nodeOfScene.addChild(kula);
        

        
        
        return nodeOfScene;
    }
    
}
