package robotscara;
import com.sun.j3d.utils.behaviors.mouse.MouseRotate;
import com.sun.j3d.utils.behaviors.mouse.MouseWheelZoom;
import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.image.TextureLoader;
import javax.media.j3d.*;
import javax.swing.*;
import java.awt.*;
import com.sun.j3d.utils.universe.SimpleUniverse;
import java.applet.Applet;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.media.j3d.Transform3D;
import javax.vecmath.Color3f;
import javax.vecmath.Point2f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

/**
 *
 * @author Michał
 */
public class RobotSCARA extends JFrame implements ActionListener, KeyListener{
    
    private SimpleUniverse universe;
    private String WINDOW_NAME = "Robot SCARA";
    private int SIZE_X_OF_MAIN_FRAME = 1000;
    private int SIZE_Y_OF_MAIN_FRAME = 1000;
    
    RobotSCARA()
    {
        
        // Tworzenie Platformy
        
        JFrame.setDefaultLookAndFeelDecorated(false);
        JFrame mainframe = new JFrame(WINDOW_NAME);
        mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainframe.setSize(new Dimension(SIZE_X_OF_MAIN_FRAME,SIZE_Y_OF_MAIN_FRAME));
        mainframe.setBackground(Color.white);
        mainframe.setResizable(false);
        mainframe.setLayout(new BorderLayout());
        mainframe.setLocationRelativeTo(null);    // gdzie się pojawia okno główne        
        
        GraphicsConfiguration configurationOfUniverse = SimpleUniverse.getPreferredConfiguration();
        
        // canvas where we put our robot
        
        Canvas3D canvas3D = new Canvas3D(configurationOfUniverse);
        mainframe.add(BorderLayout.CENTER, canvas3D);
        
        // Universe 
        BranchGroup scena = utworzScene();
        
        universe = new SimpleUniverse(canvas3D);

        

        // panele 
      
        JPanel northPanel = new JPanel();
        northPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.NORTH, northPanel);
        
        JPanel southPanel = new JPanel();
        southPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.SOUTH, southPanel);
            
        JPanel westPanel = new JPanel();
        westPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.WEST, westPanel);
        
        JPanel controlPanel = new ControlPanelControls().controlPanel();
        //controlPanel.setMaximumSize( controlPanel.getPreferredSize() );
        controlPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.EAST,controlPanel);
        
        // Adding a option to Fullscreen the frame
        addKeyBinding(mainframe.getRootPane(), "F11", new FullscreenToggleAction(mainframe));
        
        Transform3D przesuniecie_obserwatora = new Transform3D();
        Transform3D rot_obs = new Transform3D();
        rot_obs.rotY((float)(-Math.PI/6));
        przesuniecie_obserwatora.set(new Vector3f(-1.2f,1.5f,2.0f), 1.8f);
        przesuniecie_obserwatora.mul(rot_obs);
        rot_obs.rotX((float)(-Math.PI/6));
        przesuniecie_obserwatora.mul(rot_obs);

        
        universe.getViewingPlatform().getViewPlatformTransform().setTransform(przesuniecie_obserwatora);

        universe.addBranchGraph(scena);
        
        OrbitBehavior orbit = new OrbitBehavior(canvas3D, OrbitBehavior.REVERSE_ROTATE);
        orbit.setSchedulingBounds(new BoundingSphere());
        universe.getViewingPlatform().setViewPlatformBehavior(orbit);
        
        mainframe.setVisible(true);


    }
    
    public BranchGroup utworzScene() 
    {

        int i;
                
        BranchGroup nodeOfScene = new BranchGroup();

        Appearance apparanceOfPlatform = new Appearance();
        Appearance apparanceOfSky = new Appearance();
        

//        Material wmaterial_daszek = new Material(new Color3f(0.0f, 0.1f,0.0f), new Color3f(0.3f,0.0f,0.3f),
//                                             new Color3f(0.6f, 0.1f, 0.1f), new Color3f(1.0f, 0.5f, 0.5f), 80.0f);
//        wyglad_daszek.setMaterial(wmaterial_daszek);

        TextureLoader loader = new TextureLoader("images/Planet-earth-world.jpg",null);
        ImageComponent2D image = loader.getImage();

        Texture2D floor = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA,
                                        image.getWidth(), image.getHeight());

        floor.setImage(0, image);
        floor.setBoundaryModeS(Texture.WRAP);
        floor.setBoundaryModeT(Texture.WRAP);

        loader = new TextureLoader("images/hell.png",this);
        image = loader.getImage();

        Texture2D chmury = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA,
                                        image.getWidth(), image.getHeight());
        chmury.setImage(0, image);
        chmury.setBoundaryModeS(Texture.WRAP);
        chmury.setBoundaryModeT(Texture.WRAP);
        
       



        BoundingSphere bounds = new BoundingSphere();
        AmbientLight lightA = new AmbientLight();
        lightA.setInfluencingBounds(bounds);
        nodeOfScene.addChild(lightA);

        DirectionalLight lightD = new DirectionalLight();
        lightD.setInfluencingBounds(bounds);
        lightD.setDirection(new Vector3f(0.0f, 0.0f, -1.0f));
        lightD.setColor(new Color3f(1.0f, 1.0f, 1.0f));
        nodeOfScene.addChild(lightD);


        apparanceOfPlatform.setTexture(floor);
        apparanceOfSky.setTexture(chmury);
        
        Point3f[]  coords = new Point3f[4];
        for(i = 0; i< 4; i++)
            coords[i] = new Point3f();

        Point2f[]  tex_coords = new Point2f[4];
        for(i = 0; i< 4; i++)
            tex_coords[i] = new Point2f();

        float RADIUS_OF_SKY = 10f;
        float RADIOS_OF_FLOOR = RADIUS_OF_SKY +1.0f;
        
        coords[0].y = 0.0f;
        coords[1].y = 0.0f;
        coords[2].y = 0.0f;
        coords[3].y = 0.0f;

        coords[0].x = RADIOS_OF_FLOOR;
        coords[1].x = RADIOS_OF_FLOOR;
        coords[2].x = -RADIOS_OF_FLOOR;
        coords[3].x = -RADIOS_OF_FLOOR;

        coords[0].z = RADIOS_OF_FLOOR;
        coords[1].z = -RADIOS_OF_FLOOR;
        coords[2].z = -RADIOS_OF_FLOOR;
        coords[3].z = RADIOS_OF_FLOOR;

        tex_coords[0].x = 0.0f;
        tex_coords[0].y = 0.0f;

        tex_coords[1].x = 1.0f;
        tex_coords[1].y = 0.0f;

        tex_coords[2].x = 0.0f;
        tex_coords[2].y = 0.0f;

        tex_coords[3].x = 0.0f;
        tex_coords[3].y = 1.0f;


        //ziemia

        QuadArray qa_Platform = new QuadArray(4, GeometryArray.COORDINATES| GeometryArray.TEXTURE_COORDINATE_3);
        qa_Platform.setCoordinates(0,coords);
        qa_Platform.setTextureCoordinates(0, tex_coords);


        Shape3D ziemia = new Shape3D(qa_Platform);
        ziemia.setAppearance(apparanceOfPlatform);

        nodeOfScene.addChild(ziemia);


        //chmury
        
        
        Sphere sphere = new Sphere(RADIUS_OF_SKY, Sphere.GENERATE_NORMALS_INWARD| Sphere.GENERATE_TEXTURE_COORDS, apparanceOfSky);
        nodeOfScene.addChild(sphere);
  
        return nodeOfScene;
    }
    
   
    public static final void addKeyBinding(JComponent c, String key, final Action action) {
    c.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(key), key);
    c.getActionMap().put(key, action);
    c.setFocusable(true);
  }
    
    
    public static void main(String[] args) {
        new RobotSCARA();
       
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
