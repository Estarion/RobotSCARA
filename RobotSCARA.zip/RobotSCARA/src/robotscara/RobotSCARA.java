package robotscara;
import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.image.TextureLoader;
import javax.media.j3d.*;
import javax.swing.*;
import java.awt.*;
import com.sun.j3d.utils.universe.SimpleUniverse;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.media.j3d.Transform3D;
import javax.vecmath.Color3f;
import javax.vecmath.Point2f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

/**
 *
 * @author Michał
 */
public final class RobotSCARA extends JFrame implements ActionListener, KeyListener{
    
    private final SimpleUniverse universe;
    private final String WINDOW_NAME = "Robot SCARA";
    private TransformGroup positionOfRobot = null;
    private TransformGroup positionsOfObjects = null;
    private final int SIZE_X_OF_MAIN_FRAME = 1200;
    private final int SIZE_Y_OF_MAIN_FRAME = 1000;
    private final Timer clock1;
    private boolean kay_a=false, kay_s=false, kay_d=false;
    private boolean kay_w=false, kay_q=false, kay_e=false;    
    private final Transform3D rotation_1 = new Transform3D();
    private final Transform3D rotation_2 = new Transform3D();
    private final Transform3D translation_1 = new Transform3D();
    private final TransformGroup rotationOfArm1 = new TransformGroup();
    private final TransformGroup rotationOfArm2 = new TransformGroup();
    private final TransformGroup translationOfGripper = new TransformGroup();
    private double angle_1=0,angle_2=0;
    private float translation_3=0;
    
    RobotSCARA()
    {
        
        // Tworzenie Platformy
        clock1 = new Timer(10,this);     // częstość odświerzania pozycji
        //clock1.start();
        JFrame.setDefaultLookAndFeelDecorated(false);
        JFrame mainframe = new JFrame(WINDOW_NAME);
        mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainframe.setSize(new Dimension(SIZE_X_OF_MAIN_FRAME,SIZE_Y_OF_MAIN_FRAME));
        mainframe.setBackground(Color.white);
        mainframe.setResizable(false);
        mainframe.setLayout(new BorderLayout());
        mainframe.setLocationRelativeTo(null);    // gdzie się pojawia okno główne 
        
        
        GraphicsConfiguration configurationOfUniverse = SimpleUniverse.getPreferredConfiguration();
        
        // canvas where we put our robot
        
        Canvas3D canvas3D = new Canvas3D(configurationOfUniverse);
        mainframe.add(BorderLayout.CENTER, canvas3D);
        
        // Universe 
        BranchGroup scena = utworzScene();
        
        universe = new SimpleUniverse(canvas3D);

        // panele 
      
        JPanel northPanel = new JPanel();
        northPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.NORTH, northPanel);
        
        JPanel southPanel = new JPanel();
        southPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.SOUTH, southPanel);
            
        JPanel westPanel = new JPanel();
        westPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.WEST, westPanel);
        
        EastControlPanel controlPanel = new EastControlPanel();
        //controlPanel.setMaximumSize( controlPanel.getPreferredSize() );
        controlPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.EAST,controlPanel);
        
        // Adding a option to Fullscreen the frame
        //addKeyBinding(mainframe.getRootPane(), "F11", new FullscreenToggleAction(mainframe));
        
        Transform3D przesuniecie_obserwatora = new Transform3D();
        Transform3D rot_obs = new Transform3D();
        rot_obs.rotX((float)(Math.PI/6));
        przesuniecie_obserwatora.set(new Vector3f(0f,-9.0f,5.0f), 1.8f);
        przesuniecie_obserwatora.mul(rot_obs);
       //rot_obs.rotZ((float)(-Math.PI));
        przesuniecie_obserwatora.mul(rot_obs);
        
        universe.getViewingPlatform().getViewPlatformTransform().setTransform(przesuniecie_obserwatora);

        universe.addBranchGraph(scena);
        
        OrbitBehavior orbit = new OrbitBehavior(canvas3D, OrbitBehavior.REVERSE_ROTATE);
        orbit.setSchedulingBounds(new BoundingSphere());
        universe.getViewingPlatform().setViewPlatformBehavior(orbit);
        
        mainframe.setVisible(true);


    }
    
    public BranchGroup utworzScene() 
    {

        int i;
        
        // Apparance of Robot and platform where robor is
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------        
        BranchGroup nodeOfScene         = new BranchGroup();
        BranchGroup rootNodeOfRobot     = new BranchGroup();
        
        Appearance appearanceOfArms       = new Appearance();
        Appearance appearanceOfGripper    = new Appearance();
        Appearance appearanceOfBasidium   = new Appearance();
        Appearance appearanceOfBox        = new Appearance();
        Appearance appearanceOfPlatform   = new Appearance();
        Appearance appearanceOfSky        = new Appearance();
        Appearance appearanceOfSun       = new Appearance();
        
        // Loader textures
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------        
        TextureLoader loader = new TextureLoader("images/Planet-earth-world.jpg",null);
        ImageComponent2D image = loader.getImage();

        Texture2D floor = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA, image.getWidth(), image.getHeight());

        floor.setImage(0, image);
        floor.setBoundaryModeS(Texture.WRAP);
        floor.setBoundaryModeT(Texture.WRAP);

        loader = new TextureLoader("images/default.jpg",this);
        image = loader.getImage();

        Texture2D chmury = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA, image.getWidth(), image.getHeight());
        chmury.setImage(0, image);
        
        chmury.setBoundaryModeS(Texture.WRAP);
        chmury.setBoundaryModeT(Texture.WRAP);
        
        // Materials used in our project
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------        
        Material materialOfRobot1 = new Material(new Color3f(0.2f,0.2f,0.2f), new Color3f(0.1f,0.1f,0.1f),new Color3f(0.6f, 0.0f, 0.0f), new Color3f(0.0f, 0.0f, 0.0f), 80.0f);
        Material materialOfRobot2 = new Material(new Color3f(0.5f, 0.3f,0.2f), new Color3f(0.5f,0.5f,0.0f),new Color3f(0.8f, 0.3f, 0.5f), new Color3f(0.2f, 0.2f, 0.2f), 120.0f);
        Material materialOfSun = new Material(new Color3f(0.2f, 0.1f, 0.7f), new Color3f(0.2f, 0.3f, 0.1f), new Color3f(0.2f, 0.5f,0.3f), new Color3f(0.2f, 0.3f, 0.3f), 30.0f);
        Material materialOfBox = new Material(new Color3f(0.0f,0.5f,0.1f), new Color3f(0.1f,0.2f,0.3f), new Color3f(0.1f,0.1f,0.1f), new Color3f(0.1f,0.1f,0.1f), 30 );
                 
        ColoringAttributes cattr = new ColoringAttributes();
        cattr.setShadeModel(ColoringAttributes.SHADE_GOURAUD);
        

        appearanceOfArms.setMaterial(materialOfRobot1);
        appearanceOfArms.setColoringAttributes(cattr);
        appearanceOfGripper.setMaterial(materialOfRobot2);
        appearanceOfGripper.setColoringAttributes(cattr);
        appearanceOfBasidium.setMaterial(materialOfRobot2);
        appearanceOfBasidium.setColoringAttributes(cattr);
        appearanceOfBox.setMaterial(materialOfBox);
        appearanceOfBox.setColoringAttributes(cattr);
        appearanceOfSun.setMaterial(materialOfSun);
        appearanceOfSun.setColoringAttributes(cattr);
        
        appearanceOfPlatform.setTexture(floor);
        appearanceOfSky.setTexture(chmury);
        
        // Lighting
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        BoundingSphere bounds = new BoundingSphere();
        AmbientLight lightA = new AmbientLight();
        lightA.setInfluencingBounds(bounds);
        nodeOfScene.addChild(lightA);

        DirectionalLight lightD = new DirectionalLight();
        lightD.setInfluencingBounds(bounds);
        lightD.setDirection(new Vector3f(1.0f, 1.0f, -1.0f));
        lightD.setColor(new Color3f(1.0f, 1.0f, 1.0f));
        nodeOfScene.addChild(lightD);
        
        //  Cordinates of maps
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------        
        Point3f[]  coords = new Point3f[4];
        for(i = 0; i< 4; i++)
            coords[i] = new Point3f();

        Point2f[]  tex_coords = new Point2f[4];
        for(i = 0; i< 4; i++)
            tex_coords[i] = new Point2f();

        float RADIUS_OF_SKY = 10f;
        float RADIOS_OF_FLOOR = RADIUS_OF_SKY +1.0f;
        
        coords[0].z = 0.0f;
        coords[1].z = 0.0f;
        coords[2].z = 0.0f;
        coords[3].z = 0.0f;

        coords[0].x = -RADIOS_OF_FLOOR;
        coords[1].x = -RADIOS_OF_FLOOR;
        coords[2].x = RADIOS_OF_FLOOR;
        coords[3].x = RADIOS_OF_FLOOR;

        coords[0].y = RADIOS_OF_FLOOR;
        coords[1].y = -RADIOS_OF_FLOOR;
        coords[2].y = -RADIOS_OF_FLOOR;
        coords[3].y = RADIOS_OF_FLOOR;

        tex_coords[0].x = 0.0f;
        tex_coords[0].y = 0.0f;

        tex_coords[1].x = 0.0f;
        tex_coords[1].y = 1.0f;

        tex_coords[2].x = 1.0f;
        tex_coords[2].y = 1.0f;

        tex_coords[3].x = 1.0f;
        tex_coords[3].y = 0.0f;
        
        positionsOfObjects = new TransformGroup();
        rootNodeOfRobot.addChild(positionsOfObjects);
        
        positionOfRobot = new TransformGroup();
        rootNodeOfRobot.addChild(positionOfRobot);
        
        Transform3D  riser = new Transform3D();
        riser.rotX(Math.PI/-2);
        //TransformGroup TGriser = new TransformGroup(risertion);
        
        //Box1
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Point3f sizeOfTGBox = new Point3f(0.3f, 0.3f, 0.3f);
        TransformGroup TGBox = new TransformGroup();
        Transform3D przesuniecie_pudla = new Transform3D();
        przesuniecie_pudla.set(new Vector3f(2.0f,2.0f,sizeOfTGBox.z));
        TGBox.setTransform(przesuniecie_pudla);

        
        com.sun.j3d.utils.geometry.Box box1 = new com.sun.j3d.utils.geometry.Box(sizeOfTGBox.x,sizeOfTGBox.y,sizeOfTGBox.z,com.sun.j3d.utils.geometry.Box.GENERATE_NORMALS|com.sun.j3d.utils.geometry.Box.GENERATE_TEXTURE_COORDS,appearanceOfBox);//wymiary pudla
        TGBox.addChild(box1);
        positionsOfObjects.addChild(TGBox);
        
        // Basidium
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Point3f sizeOfTGBasidium = new Point3f(0.5f,0.5f,0.05f);
        TransformGroup TGBasidium = new TransformGroup();
        Transform3D t_basidium = new Transform3D();
        t_basidium.set(new Vector3f(0.0f,0.0f,sizeOfTGBasidium.z));
        TGBasidium.setTransform(t_basidium);

        com.sun.j3d.utils.geometry.Box sciana = new com.sun.j3d.utils.geometry.Box(sizeOfTGBasidium.x,sizeOfTGBasidium.y,sizeOfTGBasidium.z,com.sun.j3d.utils.geometry.Box.GENERATE_NORMALS|com.sun.j3d.utils.geometry.Box.GENERATE_TEXTURE_COORDS,appearanceOfBasidium);//wymiary podstawki
        TGBasidium.addChild(sciana);
        positionOfRobot.addChild(TGBasidium);

        // Main cylinder 
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Point2f sizeOfMainCylinder = new Point2f(0.18f, 3.5f);
        TransformGroup TGMainCylinder = new TransformGroup();
        Transform3D t_TGMainCylinder = new Transform3D();
 
        t_TGMainCylinder.set(new Vector3f(0.0f,0.0f,sizeOfMainCylinder.y/2+sizeOfTGBasidium.z));
        t_TGMainCylinder.mul(riser);
        TGMainCylinder.setTransform(t_TGMainCylinder);
        Cylinder cylinder = new Cylinder(sizeOfMainCylinder.x,sizeOfMainCylinder.y, appearanceOfGripper); //trzon

        TGMainCylinder.addChild(cylinder);
        positionOfRobot.addChild(TGMainCylinder);

        //  Arm1
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Point3f sizeOfArms = new Point3f(sizeOfMainCylinder.x, 1.4f, 0.10f);
        
        Vector3f translationVector3fOfTGArm1 = new Vector3f(0.0f,sizeOfArms.y,sizeOfMainCylinder.y+sizeOfTGBasidium.z+sizeOfArms.z);
        TransformGroup TGArm1 = new TransformGroup();
        Transform3D t_TGArm1 = new Transform3D();
        t_TGArm1.set(translationVector3fOfTGArm1);
        TGArm1.setTransform(t_TGArm1);
        com.sun.j3d.utils.geometry.Box Arm1 = new com.sun.j3d.utils.geometry.Box(sizeOfArms.x,sizeOfArms.y,sizeOfArms.z,appearanceOfArms);  
        TGArm1.addChild(Arm1);
        
        // part 1 of arm
        Point2f sizeOfArm1_parts = new Point2f(sizeOfArms.x, 2*sizeOfArms.z); //  to  both parts
        
        TransformGroup TGArm1_part1 = new TransformGroup();
        Transform3D translationOfTGArm1_part1 = new Transform3D();
        translationOfTGArm1_part1.set(new Vector3f(0.0f,-sizeOfArms.y,0.0f));
        
        translationOfTGArm1_part1.mul(riser);
        TGArm1_part1.setTransform(translationOfTGArm1_part1);      
        Cylinder part_1_CircleOfArm1 = new Cylinder(sizeOfArm1_parts.x,sizeOfArm1_parts.y,appearanceOfArms);
        TGArm1_part1.addChild(part_1_CircleOfArm1);
        TGArm1.addChild(TGArm1_part1);

        // part 2 of arm
        TransformGroup TGArm1_part2 = new TransformGroup();
        Transform3D translationOfTGArm1_part2 = new Transform3D();

        translationOfTGArm1_part2.set(new Vector3f(0.0f,sizeOfArms.y,0.0f));
        translationOfTGArm1_part2.mul(riser);
        TGArm1_part2.setTransform(translationOfTGArm1_part2);

        Cylinder part_2_CircleOfArm1 = new Cylinder(sizeOfArm1_parts.x,sizeOfArm1_parts.y,appearanceOfArms);
        TGArm1_part2.addChild(part_2_CircleOfArm1);
        TGArm1.addChild(TGArm1_part2);
        
        rotationOfArm1.addChild(TGArm1);
        positionOfRobot.addChild(rotationOfArm1); // potem to zmienić
       
       //Arm2
       //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
        TransformGroup TGArm2 = new TransformGroup();
        Transform3D t_TGArm2 = new Transform3D();
        Vector3f translationVector3fOfTGArm2 = new Vector3f(0.0f,2*sizeOfArms.y,sizeOfArms.z);
        t_TGArm2.set(translationVector3fOfTGArm2);
        TGArm2.setTransform(t_TGArm2);
        com.sun.j3d.utils.geometry.Box Arm2 = new com.sun.j3d.utils.geometry.Box(sizeOfArms.x,sizeOfArms.y,sizeOfArms.z,appearanceOfArms);
        TGArm2.addChild(Arm2);
        
        // part 1 of arm
        TransformGroup TGArm2_part1 = new TransformGroup();
        Transform3D translationOfTGArm2_part1 = new Transform3D();
        translationOfTGArm2_part1.set(new Vector3f(0.0f,-sizeOfArms.y,0.0f));
        translationOfTGArm2_part1.mul(riser);
        TGArm2_part1.setTransform(translationOfTGArm2_part1);
        Cylinder part_1_CircleOfArm2 = new Cylinder(sizeOfArm1_parts.x,sizeOfArm1_parts.y,appearanceOfArms);
        TGArm2_part1.addChild(part_1_CircleOfArm2);
        TGArm2.addChild(TGArm2_part1);
        
        // part 2 of arm
        TransformGroup TGArm2_part2 = new TransformGroup();
        Transform3D translationOfTGArm2_part2 = new Transform3D();
        
        Vector3f translationVector3fOfTGArm2_part2 = new Vector3f(0.0f,sizeOfArms.y,0.0f);
        translationOfTGArm2_part2.set(translationVector3fOfTGArm2_part2);
        translationOfTGArm2_part2.mul(riser);
        TGArm2_part2.setTransform(translationOfTGArm2_part2);
        
        Cylinder part_2_CircleOfArm2 = new Cylinder(sizeOfArm1_parts.x,sizeOfArm1_parts.y,appearanceOfArms);
        TGArm2_part2.addChild(part_2_CircleOfArm2);
        TGArm2.addChild(TGArm2_part2);
        
        rotationOfArm2.addChild(TGArm2);
        TGArm1.addChild(rotationOfArm2);

        // Cylinder Of Gripper
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Point2f sizeOfGripperCylinder = new Point2f(sizeOfMainCylinder.x/2, sizeOfMainCylinder.y+2*sizeOfArms.z);
        TransformGroup TG_cylinderOFGripper = new TransformGroup();
        Transform3D t_TG_cylinderOFGripper = new Transform3D();
        t_TG_cylinderOFGripper.set(new Vector3f(0.0f, sizeOfArms.y,-sizeOfArm1_parts.x/2));
        t_TG_cylinderOFGripper.mul(riser);
        TG_cylinderOFGripper.setTransform(t_TG_cylinderOFGripper);
        Cylinder CylinderOfGripper = new Cylinder(sizeOfGripperCylinder.x, sizeOfGripperCylinder.y, appearanceOfGripper); 
        TG_cylinderOFGripper.addChild(CylinderOfGripper);
        
        TGArm2.addChild(translationOfGripper);
        translationOfGripper.addChild(TG_cylinderOFGripper);


        // Structure of Floor
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        QuadArray qa_Platform = new QuadArray(4, GeometryArray.COORDINATES| GeometryArray.TEXTURE_COORDINATE_3);
        qa_Platform.setCoordinates(0,coords);
        qa_Platform.setTextureCoordinates(0, tex_coords);


        Shape3D ziemia = new Shape3D(qa_Platform);
        ziemia.setAppearance(appearanceOfPlatform);

        nodeOfScene.addChild(ziemia);


        // Structure of Sky
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------        
        int Gładkość_kuli = 80;
        Sphere sphere = new Sphere(RADIUS_OF_SKY, Sphere.GENERATE_NORMALS_INWARD| Sphere.GENERATE_TEXTURE_COORDS,Gładkość_kuli, appearanceOfSky);
        nodeOfScene.addChild(sphere);
        
        nodeOfScene.addChild(rootNodeOfRobot);
  
        return nodeOfScene;
    }
    
   
    public static final void addKeyBinding(JComponent c, String key, final Action action) {
    c.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(key), key);
    c.getActionMap().put(key, action);
    c.setFocusable(true);
  }
    
    
    public static void main(String[] args) {           
        RobotSCARA robot = new RobotSCARA();
        robot.addKeyListener(robot);
       
    }

    @Override
    public void actionPerformed(ActionEvent e) {
//        if(e.getSource()==przyciskStart) {
//            if(!zegar_1.isRunning()) {zegar_1.start();} //jeżeli naciśnięto "start" - uruchomienie zegara 1
//        } else {
//            height += .01*sign;
//            if(Math.abs(height*2)>=1)sign=-1.0f*sign;
//            if(height<-0.4f) {
//                trans.setScale(new Vector3d(1.0,1.0,1.0));
//            }
        if(angle_1 > -2.65){
            if(kay_d==true){angle_1=angle_1-0.03;}
        }
        if(angle_1 < 2.65){
            if(kay_a==true){angle_1=angle_1+0.03;}
        }
        if(angle_2 > -2.65){
            if(kay_e==true){angle_2=angle_2-0.04;}
        }
        if(angle_2 < 2.65){
            if(kay_q==true){angle_2=angle_2+0.04;}
        }
        if(-0.3f < translation_3){
            if(kay_s==true){translation_3=translation_3-0.005f;}
        }
        if(translation_3 < 0.3f){
            if(kay_w==true){translation_3=translation_3+0.005f;}
        }

        rotation_1.rotY(angle_1);
        rotationOfArm1.setTransform(rotation_1);

        rotation_2.rotY(angle_2);
        rotationOfArm2.setTransform(rotation_2);

        translation_1.setTranslation(new Vector3f(0f, 0.0f,translation_3));
        translationOfGripper.setTransform(translation_1);
    }


    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyChar()=='d') {kay_d=true;}
        if (e.getKeyChar()=='a') {kay_a=true;}
        if (e.getKeyChar()=='w') {kay_w=true;}
        if (e.getKeyChar()=='s') {kay_s=true;}
        if (e.getKeyChar()=='q') {kay_q=true;}
        if (e.getKeyChar()=='e') {kay_e=true;}
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyChar()=='a') {kay_a=false;}
        if (e.getKeyChar()=='d') {kay_d=false;}
        if (e.getKeyChar()=='w') {kay_w=false;}
        if (e.getKeyChar()=='s') {kay_s=false;}
        if (e.getKeyChar()=='q') {kay_q=false;}
        if (e.getKeyChar()=='e') {kay_e=false;}
    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
