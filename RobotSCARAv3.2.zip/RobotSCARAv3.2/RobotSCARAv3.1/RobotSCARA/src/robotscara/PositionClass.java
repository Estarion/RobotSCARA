/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robotscara;
/**
 *
 * @author Michał
 */
public class PositionClass {
    
    double angle1 = 0;
    double angle2 = 0.0f;
    double position3 = 0.0f;
    
    ObjectClass box1Class = new ObjectClass();
    ObjectClass box2Class = new ObjectClass();
    
    PositionClass(double angle1, double angle2, double position3, ObjectClass box1Class, ObjectClass box2Class )
    {
        this.angle1 = angle1;
        this.angle2 = angle2;
        this.position3 = position3;
        this.box1Class = box1Class;
        this.box2Class = box2Class;
    }
    double getAngle1(){ return angle1; }
    double getAngle2(){ return angle2; }
    double getPositon3(){ return position3; }
    ObjectClass getBox1Class(){ return box1Class; }
    ObjectClass getBox2Class(){ return box2Class; }
    
    void setAngle1(double angle1){ this.angle2 = angle1; }
    void setAngle2(double angle2){ this.angle2 = angle2; }
    void setPosition3(double position3){ this.position3 = position3; }
    void setBox1Class(ObjectClass box1Class){ this.box1Class = box1Class; }
    void setBox2Class(ObjectClass box2Class){ this.box2Class = box2Class; }
}
