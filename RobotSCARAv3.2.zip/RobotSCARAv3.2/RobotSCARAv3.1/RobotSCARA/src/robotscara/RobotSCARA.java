package robotscara;
import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.image.TextureLoader;
import javax.media.j3d.*;
import javax.swing.*;
import java.awt.*;
import com.sun.j3d.utils.universe.SimpleUniverse;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.LinkedList;
import java.util.Queue;
import javax.media.j3d.Transform3D;
import javax.vecmath.Color3f;
import javax.vecmath.Point2f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Vector2f;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;
import com.sun.j3d.utils.geometry.Box;

/**
 *
 * @author Michał
 */
public final class RobotSCARA extends JFrame implements ActionListener, KeyListener{
    
    private final SimpleUniverse universe;
    private final String WINDOW_NAME = "Robot SCARA";
    private TransformGroup positionOfRobot = null;
    private TransformGroup positionsOfObjects = null;
    private final int SIZE_X_OF_MAIN_FRAME = 1200;
    private final int SIZE_Y_OF_MAIN_FRAME = 800;
    int FREQUENCY_OF_CLOCS = 10;
    private final Timer clock1;
    boolean activeRecording = false;
    private boolean activeRecreating = false;
    private boolean kay_a=false, kay_s=false, kay_d=false;
    private boolean kay_w=false, kay_q=false, kay_e=false;
    private boolean kay_enter_catch = false;
    private final Transform3D rotation_1 = new Transform3D();
    private final Transform3D rotation_2 = new Transform3D();
    private final Transform3D translation_1 = new Transform3D();
    private final TransformGroup rotationOfArm1 = new TransformGroup();
    private final TransformGroup rotationOfArm2 = new TransformGroup();
    private final TransformGroup translationOfGripper = new TransformGroup();
    private double angle_1=0,angle_2=0;
    private double translation_3=0;
    Vector3f translationVectorOfViewingPlatform;
    private final Point2f sizeOfMainCylinder = new Point2f(0.2f, 1.5f);
    private final Point3f sizeOfArms = new Point3f(sizeOfMainCylinder.x/2, 0.6f, 0.1f);
    private final Point2f sizeOfGripperCylinder = new Point2f(sizeOfMainCylinder.x, sizeOfMainCylinder.y+2*sizeOfArms.z);
    Queue<PositionClass> recreatingQueue = new LinkedList<>();
    Queue<PositionClass> cloneOfRecreatingQueue = new LinkedList<>();
    EastControlPanel controlPanel = new EastControlPanel();
    Transform3D przesuniecie_obserwatora = new Transform3D();
    Transform3D rot_obs = new Transform3D();
    
    //Needed for box picking
    BranchGroup BG_endOfCylinderGripper;//grabbed box put 
    BranchGroup BG_positionOfBoxes; //ungrabbed boxes stored here
    BranchGroup BGBox1; //positionOfRobot_BranchGroupBox1
    BranchGroup BGBox2; //positionOfRobot_BranchGroupBox2
    
    boolean box1Picked = false;
    boolean box2Picked = false;
    boolean kay_g = false;
    
    Bounds boundsOfBox1;
    Bounds boundsOfBox2;
    Bounds boundsOfEndOfGripper;
    
    Transform3D box1PositionTransform3D;
    Transform3D box2PositionTransform3D;
    TransformGroup TGBox1;
      
    RobotSCARA()
    {
        
        // Tworzenie Platformy

        JFrame.setDefaultLookAndFeelDecorated(false);
        JFrame mainframe = new JFrame(WINDOW_NAME);
        mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainframe.setSize(new Dimension(SIZE_X_OF_MAIN_FRAME,SIZE_Y_OF_MAIN_FRAME));
        mainframe.setBackground(Color.white);
        mainframe.setResizable(false);
        mainframe.setLayout(new BorderLayout());
        mainframe.setLocationRelativeTo(null);    // gdzie się pojawia okno główne 
        clock1 = new Timer(FREQUENCY_OF_CLOCS,this);
        
        
        GraphicsConfiguration configurationOfUniverse = SimpleUniverse.getPreferredConfiguration();
        
        // canvas where we put our robot
        
        Canvas3D canvas3D = new Canvas3D(configurationOfUniverse);
        canvas3D.addKeyListener(this);
        mainframe.add(BorderLayout.CENTER, canvas3D);
        
        // Universe 
        BranchGroup scena = utworzScene();
        
        
        universe = new SimpleUniverse(canvas3D);
          
        // panele 
      
        JPanel northPanel = new JPanel();
        northPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.NORTH, northPanel);
        
        JPanel southPanel = new JPanel();
        southPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.SOUTH, southPanel);
            
        JPanel westPanel = new JPanel();
        westPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.WEST, westPanel);
        
        controlPanel.setBackground(Color.white);
        mainframe.add(BorderLayout.EAST,controlPanel);
        
        controlPanel.startRecordButton.addActionListener(this);
        controlPanel.stopRecordButton.addActionListener(this);
        controlPanel.startRecreateMovementButton.addActionListener(this);
        controlPanel.stopRecreateMovementButton.addActionListener(this);
        controlPanel.resetButton.addActionListener(this);
        
        // Adding a option to Fullscreen the frame
        addKeyBinding(mainframe.getRootPane(), "F11", new FullscreenToggleAction(mainframe));

        rot_obs.rotX((float)(Math.PI/6));
        translationVectorOfViewingPlatform = new Vector3f(0.0f,-9.0f,5.0f);
        przesuniecie_obserwatora.set(translationVectorOfViewingPlatform , 1.8f);
        przesuniecie_obserwatora.mul(rot_obs);
        przesuniecie_obserwatora.mul(rot_obs);
        
        universe.getViewingPlatform().getViewPlatformTransform().setTransform(przesuniecie_obserwatora);

        universe.addBranchGraph(scena);
        
        OrbitBehavior orbit = new OrbitBehavior(canvas3D, OrbitBehavior.REVERSE_ROTATE);
        orbit.setSchedulingBounds(new BoundingSphere());
        universe.getViewingPlatform().setViewPlatformBehavior(orbit);
        
        mainframe.setVisible(true);
        
        if(!clock1.isRunning()) 
            {
                clock1.start();
            }


    }
    
    public BranchGroup utworzScene() 
    {
        
        // Apparance of Robot and platform where robor is
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------        
        BranchGroup nodeOfScene         = new BranchGroup();
        BranchGroup rootNodeOfRobot     = new BranchGroup();
        
        Appearance appearanceOfArms       = new Appearance();
        Appearance appearanceOfGripper    = new Appearance();
        Appearance appearanceOfBasidium   = new Appearance();
        Appearance appearanceOfBox        = new Appearance();
        Appearance appearanceOfPlatform   = new Appearance();
        Appearance appearanceOfSky        = new Appearance();
        
        // Loader textures
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------        
        TextureLoader loader = new TextureLoader("images/metal_floor.jpg",null);
        ImageComponent2D image = loader.getImage();

        Texture2D floor = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA, image.getWidth(), image.getHeight());

        floor.setImage(0, image);
        floor.setBoundaryModeS(Texture.WRAP);
        floor.setBoundaryModeT(Texture.WRAP);

        loader = new TextureLoader("images/default.jpg",this);
        image = loader.getImage();

        Texture2D chmury = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA, image.getWidth(), image.getHeight());
        chmury.setImage(0, image);
        
        chmury.setBoundaryModeS(Texture.WRAP);
        chmury.setBoundaryModeT(Texture.WRAP);
        
        loader = new TextureLoader("images/robot_texture.jpg",this);
        image = loader.getImage();

        Texture2D robot = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA, image.getWidth(), image.getHeight());
        robot.setImage(0, image);
        
        robot.setBoundaryModeS(Texture.WRAP);
        robot.setBoundaryModeT(Texture.WRAP);

        loader = new TextureLoader("images/robot_texture_vertical.jpg",this);
        image = loader.getImage();

        Texture2D robotVertical = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA, image.getWidth(), image.getHeight());
        robotVertical.setImage(0, image);
        
        robotVertical.setBoundaryModeS(Texture.WRAP);
        robotVertical.setBoundaryModeT(Texture.WRAP);        
        // Materials used in our project
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------        
        Material materialOfBox = new Material(new Color3f(0.0f,0.5f,0.1f), new Color3f(0.1f,0.2f,0.3f), new Color3f(0.1f,0.1f,0.1f), new Color3f(0.1f,0.1f,0.1f), 30 );
                 
        ColoringAttributes cattr = new ColoringAttributes();
        cattr.setShadeModel(ColoringAttributes.SHADE_GOURAUD);
        
        appearanceOfBox.setMaterial(materialOfBox);
        appearanceOfBox.setColoringAttributes(cattr);
        appearanceOfBox.setCapability(appearanceOfBox.ALLOW_COLORING_ATTRIBUTES_WRITE);
        
        appearanceOfPlatform.setTexture(floor);
        appearanceOfSky.setTexture(chmury);
        appearanceOfArms.setTexture(robot);
        appearanceOfBasidium.setTexture(robot);
        appearanceOfGripper.setTexture(robotVertical);
        
        //----------
        TexCoordGeneration gripperCoord = new TexCoordGeneration(TexCoordGeneration.SPHERE_MAP, TexCoordGeneration.TEXTURE_COORDINATE_2);
        appearanceOfGripper.setTexCoordGeneration(gripperCoord);
        TexCoordGeneration armsCoord = new TexCoordGeneration(TexCoordGeneration.SPHERE_MAP, TexCoordGeneration.TEXTURE_COORDINATE_2);
        appearanceOfArms.setTexCoordGeneration(armsCoord);
        //=======
        
        
        //  Cordinates of maps
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------        
        Point3f[]  coords = new Point3f[4];
        Point3f[]  coords2 = new Point3f[4];
        
        Point2f[]  tex_coords = new Point2f[4];
        for(int i = 0; i< 4; i++)
        {
            coords[i] = new Point3f();
            coords2[i] = new Point3f();
            tex_coords[i] = new Point2f();
        }

        float RADIUS_OF_SKY = 12f;
        float RADIOS_OF_FLOOR = RADIUS_OF_SKY ;
        
        coords[0].z = 0.0f;
        coords[1].z = 0.0f;
        coords[2].z = 0.0f;
        coords[3].z = 0.0f;

        coords[0].x = -RADIOS_OF_FLOOR;
        coords[1].x = -RADIOS_OF_FLOOR;
        coords[2].x = RADIOS_OF_FLOOR;
        coords[3].x = RADIOS_OF_FLOOR;

        coords[0].y = RADIOS_OF_FLOOR;
        coords[1].y = -RADIOS_OF_FLOOR;
        coords[2].y = -RADIOS_OF_FLOOR;
        coords[3].y = RADIOS_OF_FLOOR;
        
        coords2[0].z = -0.01f;
        coords2[1].z = -0.01f;
        coords2[2].z = -0.01f;
        coords2[3].z = -0.01f;

        coords2[0].y = -RADIOS_OF_FLOOR;
        coords2[1].y = -RADIOS_OF_FLOOR;
        coords2[2].y = RADIOS_OF_FLOOR;
        coords2[3].y = RADIOS_OF_FLOOR;

        coords2[0].x = RADIOS_OF_FLOOR;
        coords2[1].x = -RADIOS_OF_FLOOR;
        coords2[2].x = -RADIOS_OF_FLOOR;
        coords2[3].x = RADIOS_OF_FLOOR;

        tex_coords[0].x = 0.0f;
        tex_coords[0].y = 0.0f;

        tex_coords[1].x = 0.0f;
        tex_coords[1].y = 1.0f;

        tex_coords[2].x = 1.0f;
        tex_coords[2].y = 1.0f;

        tex_coords[3].x = 1.0f;
        tex_coords[3].y = 0.0f;
        
        // ControlUniverseGroups
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        
        positionsOfObjects = new TransformGroup();
        BG_positionOfBoxes = new BranchGroup();
        positionsOfObjects.addChild(BG_positionOfBoxes);
        rootNodeOfRobot.addChild(positionsOfObjects);
        
        BG_positionOfBoxes.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);  //Zezwolenia potrzebne do animacji
        BG_positionOfBoxes.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
        BG_positionOfBoxes.setCapability(TransformGroup.ALLOW_CHILDREN_READ);
        BG_positionOfBoxes.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
        BG_positionOfBoxes.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        BG_positionOfBoxes.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
        
        positionOfRobot = new TransformGroup();
        rootNodeOfRobot.addChild(positionOfRobot);
        
        Transform3D  riser = new Transform3D();
        riser.rotX(Math.PI/-2);
        
        // Lighting
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Point3d poczatekSwiecenia = new Point3d(0.0f, 0.0f, 0.0f);
        BoundingSphere bounds = new BoundingSphere(poczatekSwiecenia,RADIUS_OF_SKY);
        
        DirectionalLight lightD = new DirectionalLight();
        lightD.setInfluencingBounds(bounds);
        lightD.setDirection(new Vector3f(RADIUS_OF_SKY, RADIUS_OF_SKY, -RADIUS_OF_SKY));
        lightD.setColor(new Color3f(1.0f, 1.0f, 1.0f));
        nodeOfScene.addChild(lightD);
        
        //Box1
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Point3f sizeOfTGBox1 = new Point3f(0.2f, 0.2f, 0.2f);
        TGBox1 = new TransformGroup();
        Transform3D t_TGBox1 = new Transform3D();
        
        TGBox1.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        
        float startXBox1Position = 1.0f;
        float startYBox1Position = 1.0f;
        float startZBox1Position = sizeOfTGBox1.z;
        Vector3f baseTransformVectorBox1 = new Vector3f(startXBox1Position,startYBox1Position,startZBox1Position);
        
        box1PositionTransform3D = new Transform3D();
        
        BGBox1 = new BranchGroup();
        t_TGBox1.set(baseTransformVectorBox1);
        TGBox1.setTransform(t_TGBox1);
        
        BGBox1.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);  //Zezwolenia potrzebne do animacji
        BGBox1.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
        BGBox1.setCapability(TransformGroup.ALLOW_CHILDREN_READ);
        BGBox1.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
        BGBox1.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        BGBox1.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
        
        Box box1 = new Box(sizeOfTGBox1.x,sizeOfTGBox1.y,sizeOfTGBox1.z,
                Box.GENERATE_NORMALS|Box.GENERATE_TEXTURE_COORDS,appearanceOfBox);//wymiary pudla
        TGBox1.addChild(box1);
        BGBox1.addChild(TGBox1);
        BG_positionOfBoxes.addChild(BGBox1);

        boundsOfBox1 = new BoundingBox();
        //boundsOfBox1 = box1.getBounds();
        box1.setBounds(boundsOfBox1);
        System.out.println(box1.getBounds().toString());
        
        //Box2
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Point3f sizeOfTGBox2 = new Point3f(0.2f, 0.2f, 0.2f);
        TransformGroup TGBox2 = new TransformGroup();
        Transform3D t_TGBox2 = new Transform3D();
        BGBox2 = new BranchGroup();
        t_TGBox2.set(new Vector3f(-1.0f,1.0f,sizeOfTGBox2.z));
        TGBox2.setTransform(t_TGBox2);
        
        BGBox2.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);  //Zezwolenia potrzebne do animacji
        BGBox2.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
        BGBox2.setCapability(TransformGroup.ALLOW_CHILDREN_READ);
        BGBox2.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
        BGBox2.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        BGBox2.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
        
        Box box2 = new Box(sizeOfTGBox2.x,sizeOfTGBox2.y,sizeOfTGBox2.z,
                            Box.GENERATE_NORMALS|Box.GENERATE_TEXTURE_COORDS,appearanceOfBox);//wymiary pudla
        TGBox2.addChild(box2);
        BGBox2.addChild(TGBox2);
        BG_positionOfBoxes.addChild(BGBox2);

        
        // Basidium
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Point3f sizeOfTGBasidium = new Point3f(0.3f,0.3f,0.05f);
        TransformGroup TGBasidium = new TransformGroup();
        Transform3D t_basidium = new Transform3D();
        t_basidium.set(new Vector3f(0.0f,0.0f,sizeOfTGBasidium.z));
        TGBasidium.setTransform(t_basidium);

        Box sciana = new Box(sizeOfTGBasidium.x,sizeOfTGBasidium.y,sizeOfTGBasidium.z,
                Box.GENERATE_NORMALS|Box.GENERATE_TEXTURE_COORDS,appearanceOfBasidium);//wymiary podstawki
        TGBasidium.addChild(sciana);
        positionOfRobot.addChild(TGBasidium);

        // Main cylinder 
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        
        TransformGroup TGMainCylinder = new TransformGroup();
        Transform3D t_TGMainCylinder = new Transform3D();
 
        t_TGMainCylinder.set(new Vector3f(0.0f,0.0f,sizeOfMainCylinder.y/2+sizeOfTGBasidium.z));
        t_TGMainCylinder.mul(riser);
        TGMainCylinder.setTransform(t_TGMainCylinder);
        Cylinder cylinder = new Cylinder(sizeOfMainCylinder.x,sizeOfMainCylinder.y,
                                Cylinder.GENERATE_NORMALS|Cylinder.GENERATE_TEXTURE_COORDS,appearanceOfGripper); 

        TGMainCylinder.addChild(cylinder);
        positionOfRobot.addChild(TGMainCylinder);

        //  Arm1
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        
        Vector3f translationVector3fOfTGArm1 = new Vector3f(0.0f,sizeOfArms.y,sizeOfMainCylinder.y+sizeOfTGBasidium.z+sizeOfArms.z);
        TransformGroup TGArm1 = new TransformGroup();
        Transform3D t_TGArm1 = new Transform3D();
        t_TGArm1.set(translationVector3fOfTGArm1);
        TGArm1.setTransform(t_TGArm1);
        Box Arm1 = new Box(sizeOfArms.x,sizeOfArms.y,sizeOfArms.z,
                        Box.GENERATE_NORMALS|Box.GENERATE_TEXTURE_COORDS,appearanceOfArms);  
        TGArm1.addChild(Arm1);
        
        // part 1 of arm
        Point2f sizeOfArm1_parts = new Point2f(sizeOfArms.x, 2*sizeOfArms.z); //  to  both parts
        
        TransformGroup TGArm1_part1 = new TransformGroup();
        Transform3D translationOfTGArm1_part1 = new Transform3D();
        translationOfTGArm1_part1.set(new Vector3f(0.0f,-sizeOfArms.y,0.0f));
        
        translationOfTGArm1_part1.mul(riser);
        TGArm1_part1.setTransform(translationOfTGArm1_part1);      
        Cylinder part_1_CircleOfArm1 = new Cylinder(sizeOfArm1_parts.x,sizeOfArm1_parts.y,Cylinder.GENERATE_NORMALS | Cylinder.GENERATE_NORMALS_INWARD| Cylinder.GENERATE_TEXTURE_COORDS,appearanceOfArms);
        TGArm1_part1.addChild(part_1_CircleOfArm1);
        TGArm1.addChild(TGArm1_part1);

        // part 2 of arm
        TransformGroup TGArm1_part2 = new TransformGroup();
        Transform3D translationOfTGArm1_part2 = new Transform3D();

        translationOfTGArm1_part2.set(new Vector3f(0.0f,sizeOfArms.y,0.0f));
        translationOfTGArm1_part2.mul(riser);
        TGArm1_part2.setTransform(translationOfTGArm1_part2);

        Cylinder part_2_CircleOfArm1 = new Cylinder(sizeOfArm1_parts.x,sizeOfArm1_parts.y,
                                                    Cylinder.GENERATE_NORMALS | Cylinder.GENERATE_NORMALS_INWARD| Cylinder.GENERATE_TEXTURE_COORDS,
                                                    appearanceOfArms);
        TGArm1_part2.addChild(part_2_CircleOfArm1);
        TGArm1.addChild(TGArm1_part2);
        
        rotationOfArm1.setCapability( TransformGroup.ALLOW_TRANSFORM_WRITE);
        rotationOfArm1.setCapability( TransformGroup.ALLOW_TRANSFORM_READ);
        rotationOfArm1.addChild(TGArm1);
        positionOfRobot.addChild(rotationOfArm1); 
       
       //Arm2
       //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
       
       float sizeplus = 0.1f;
        TransformGroup TGArm2 = new TransformGroup();
        Transform3D t_TGArm2 = new Transform3D();
        Vector3f translationVector3fOfTGArm2 = new Vector3f(0.0f,sizeOfArms.y,2*sizeOfArms.z + sizeplus);
        t_TGArm2.set(translationVector3fOfTGArm2);
        TGArm2.setTransform(t_TGArm2);
        Box Arm2 = new Box(sizeOfArms.x,sizeOfArms.y,sizeOfArms.z+sizeplus,Box.GENERATE_NORMALS | Box.GENERATE_NORMALS_INWARD| Box.GENERATE_TEXTURE_COORDS,appearanceOfArms);
        TGArm2.addChild(Arm2);

        // part 1 of arm
        TransformGroup TGArm2_part1 = new TransformGroup();
        Transform3D translationOfTGArm2_part1 = new Transform3D();
        translationOfTGArm2_part1.set(new Vector3f(0.0f,-sizeOfArms.y,0.0f));
        translationOfTGArm2_part1.mul(riser);
        TGArm2_part1.setTransform(translationOfTGArm2_part1);
        Cylinder part_1_CircleOfArm2 = new Cylinder(sizeOfArm1_parts.x,sizeOfArm1_parts.y + sizeplus*2,appearanceOfArms);
        TGArm2_part1.addChild(part_1_CircleOfArm2);
        TGArm2.addChild(TGArm2_part1);

        // part 2 of arm
        TransformGroup TGArm2_part2 = new TransformGroup();
        Transform3D translationOfTGArm2_part2 = new Transform3D();

        Vector3f translationVector3fOfTGArm2_part2 = new Vector3f(0.0f,sizeOfArms.y,0.0f);
        translationOfTGArm2_part2.set(translationVector3fOfTGArm2_part2);
        translationOfTGArm2_part2.mul(riser);
        TGArm2_part2.setTransform(translationOfTGArm2_part2);

        Cylinder part_2_CircleOfArm2 = new Cylinder(sizeOfArm1_parts.x,sizeOfArm1_parts.y+ sizeplus*2,appearanceOfArms);
        TGArm2_part2.addChild(part_2_CircleOfArm2);
        TGArm2.addChild(TGArm2_part2);
        rotationOfArm2.setCapability( TransformGroup.ALLOW_TRANSFORM_WRITE);
        rotationOfArm2.setCapability( TransformGroup.ALLOW_TRANSFORM_READ);

        TransformGroup translationTG = new TransformGroup();
        Transform3D t_translationTG = new Transform3D();
        t_translationTG.set(new Vector3f(0.0f,sizeOfArms.y,0.0f));
        translationTG.setTransform(t_translationTG);

        rotationOfArm2.addChild(TGArm2);
        translationTG.addChild(rotationOfArm2);
        TGArm1.addChild(translationTG);

        // Cylinder Of Gripper
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------

        
       Vector2f cylinderGripperSize = new Vector2f(sizeOfGripperCylinder.x/3, sizeOfGripperCylinder.y + sizeplus);
        TransformGroup TG_cylinderOFGripper = new TransformGroup();
        Transform3D t_TG_cylinderOFGripper = new Transform3D();
        t_TG_cylinderOFGripper.set(new Vector3f(0.0f, sizeOfArms.y,-sizeOfArm1_parts.x/2));
        t_TG_cylinderOFGripper.mul(riser);
        TG_cylinderOFGripper.setTransform(t_TG_cylinderOFGripper);
        Cylinder CylinderOfGripper = new Cylinder(cylinderGripperSize.x, cylinderGripperSize.y, appearanceOfGripper); 
        TG_cylinderOFGripper.addChild(CylinderOfGripper);

        translationOfGripper.setCapability( TransformGroup.ALLOW_TRANSFORM_WRITE);
        translationOfGripper.setCapability( TransformGroup.ALLOW_TRANSFORM_READ);
        TGArm2.addChild(translationOfGripper);
        translationOfGripper.addChild(TG_cylinderOFGripper);
        
        TransformGroup TG_endOfCylinderGripper = new TransformGroup();
        Transform3D t_TG_endOfCylinderGripper = new Transform3D();
        //for box picking
        BG_endOfCylinderGripper = new BranchGroup();
        BG_endOfCylinderGripper.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        BG_endOfCylinderGripper.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
        BG_endOfCylinderGripper.setCapability(TransformGroup.ALLOW_CHILDREN_READ);
        BG_endOfCylinderGripper.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
        BG_endOfCylinderGripper.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        BG_endOfCylinderGripper.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
        
        boundsOfEndOfGripper = new BoundingBox();
        boundsOfEndOfGripper = CylinderOfGripper.getBounds();
        System.out.println(boundsOfEndOfGripper.toString());
                
        t_TG_endOfCylinderGripper.set(new Vector3f(0.0f,cylinderGripperSize.y/2 + sizeOfTGBox1.z , 0.0f));
        //Poprawić 0.05f aby zawszę brało góre obiektu a nie punkt obniżony o 0.5f 
        TG_endOfCylinderGripper.setTransform(t_TG_endOfCylinderGripper);
        
        //BG_endOfCylinderGripper.addChild(BGBox2);
        TG_endOfCylinderGripper.addChild(BG_endOfCylinderGripper);
        TG_cylinderOFGripper.addChild(TG_endOfCylinderGripper);


        // Structure of Floor
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        QuadArray qa_Platform = new QuadArray(4, GeometryArray.COORDINATES| GeometryArray.TEXTURE_COORDINATE_3);
        qa_Platform.setCoordinates(0,coords);
        qa_Platform.setTextureCoordinates(0, tex_coords);


        Shape3D ziemia = new Shape3D(qa_Platform);
        ziemia.setAppearance(appearanceOfPlatform);

        nodeOfScene.addChild(ziemia);
        
        QuadArray qa_Platform2 = new QuadArray(4, GeometryArray.COORDINATES| GeometryArray.TEXTURE_COORDINATE_3);
        qa_Platform2.setCoordinates(0,coords2);
        qa_Platform2.setTextureCoordinates(0, tex_coords);


        Shape3D ziemia2 = new Shape3D(qa_Platform2);
        ziemia2.setAppearance(appearanceOfPlatform);

        nodeOfScene.addChild(ziemia2);


        // Structure of Sky
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------        
        int Gładkość_kuli = 80;
        Sphere sphere = new Sphere(RADIUS_OF_SKY, Sphere.GENERATE_NORMALS_INWARD| Sphere.GENERATE_TEXTURE_COORDS,Gładkość_kuli, appearanceOfSky);
        nodeOfScene.addChild(sphere);

        nodeOfScene.addChild(rootNodeOfRobot);

        return nodeOfScene;
        
    }    
   
    public static final void addKeyBinding(JComponent c, String key, final Action action) {
    c.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(key), key);
    c.getActionMap().put(key, action);
    c.setFocusable(true);
  }
    
    
    public static void main(String[] args) {           
    RobotSCARA robot = new RobotSCARA();
        
       
    }


    @Override
    public void actionPerformed(ActionEvent e) {  

        if (null != e.getActionCommand()) switch (e.getActionCommand()) {
            case "startRecord":
                activeRecording = true;
                recreatingQueue.clear();
                cloneOfRecreatingQueue.clear();
                break;
            case "stopRecord":
                activeRecording = false;
                break;
            case "startRecreateMovement":
                activeRecreating = true ;
                break;
            case "stopRecreateMovement":
                activeRecreating = false;
                recreatingQueue.removeAll(recreatingQueue);
                break;
            case "activeReset":
                translationVectorOfViewingPlatform = new Vector3f(0.0f,-9.0f,5.0f);
                przesuniecie_obserwatora.set(translationVectorOfViewingPlatform , 1.8f);
                przesuniecie_obserwatora.mul(rot_obs);
                przesuniecie_obserwatora.mul(rot_obs);
                universe.getViewingPlatform().getViewPlatformTransform().setTransform(przesuniecie_obserwatora);
                break;
            default:
                break;
        }
        
        if ( activeRecording == true)
        {
            BGBox1.getLocalToVworld(box1PositionTransform3D);
            ObjectClass classOfBox1 = new ObjectClass(box1Picked, kay_g, box1PositionTransform3D);
            ObjectClass classOfBox2 = new ObjectClass(box2Picked, kay_g, box1PositionTransform3D);  // zmienić na box2
            PositionClass library = new PositionClass(angle_1, angle_2, translation_3, classOfBox1, classOfBox2);
            recreatingQueue.add(library);
            
            cloneOfRecreatingQueue.add(library);
            
        }
        
        else
        {
            

        }
        
        if ( activeRecreating == true)
        {
            if (!recreatingQueue.isEmpty())
            {
                angle_1 = recreatingQueue.element().angle1;
                angle_2 = recreatingQueue.element().angle2;
                translation_3 =  recreatingQueue.element().position3;
                box1Picked = recreatingQueue.element().box1Class.picked;
                box2Picked = recreatingQueue.element().box2Class.picked;
                kay_g = recreatingQueue.element().box1Class.activeKay;
                if(kay_g && !box1Picked){
                    BGBox1.getLocalToVworld(box1PositionTransform3D);
                    BG_positionOfBoxes.removeChild(BGBox1);
                    BG_endOfCylinderGripper.addChild(BGBox1);
                    TGBox1.setTransform(box1PositionTransform3D);
                    box1Picked = true;
                }
                else if(!kay_g && box1Picked){
                    BGBox1.getLocalToVworld(box1PositionTransform3D);
                    BG_endOfCylinderGripper.removeChild(BGBox1);
                    BG_positionOfBoxes.addChild(BGBox1);
                    TGBox1.setTransform(box1PositionTransform3D);
                    box1Picked = false;
                }
                else if (!kay_g && !box1Picked)
                {
                    System.out.println(recreatingQueue.element().box1Class.position.toString());
                    TGBox1.setTransform(recreatingQueue.element().box1Class.position);
                }
                
                recreatingQueue.remove();
                   
            }
        }
        else
        {
            if (recreatingQueue.size() != cloneOfRecreatingQueue.size())
            {
                cloneOfRecreatingQueue.forEach((library) -> {
                    recreatingQueue.add(new PositionClass(library.angle1, library.angle2, library.position3, library.box1Class, library.box2Class));
                });  
            }
        }
        
        if (!activeRecreating )
        {
            if(angle_1 > -Math.PI){
                if(kay_d==true){angle_1=angle_1-0.025;}
            }
            if(angle_1 < Math.PI){
                if(kay_a==true){angle_1=angle_1+0.025;}
            }
            if(angle_2 > -Math.PI*160/180){
                if(kay_e==true){angle_2=angle_2-0.02;}
            }
            if(angle_2 < Math.PI*160/180){
                if(kay_q==true){angle_2=angle_2+0.02;}
            }
            if(-sizeOfGripperCylinder.y/2 < translation_3){
                if(kay_s==true){translation_3=translation_3-0.05f/sizeOfMainCylinder.y;}
            }
            if(translation_3 < sizeOfGripperCylinder.y/2){
                if(kay_w==true){translation_3=translation_3+0.05f/sizeOfMainCylinder.y;}
            } 
            if(boundsOfEndOfGripper.intersect(boundsOfBox1)){
                if(kay_g && !box1Picked){
                    BGBox1.getLocalToVworld(box1PositionTransform3D);
                    BG_positionOfBoxes.removeChild(BGBox1);
                    BG_endOfCylinderGripper.addChild(BGBox1);
                    TGBox1.setTransform(box1PositionTransform3D);
                    box1Picked = true;
                }
                else if(!kay_g && box1Picked){
                    BGBox1.getLocalToVworld(box1PositionTransform3D);
                    BG_endOfCylinderGripper.removeChild(BGBox1);
                    BG_positionOfBoxes.addChild(BGBox1);
                    TGBox1.setTransform(box1PositionTransform3D);
                    box1Picked = false;
                }
                 
            }
        }
        

        rotation_1.rotZ(angle_1);
        rotationOfArm1.setTransform(rotation_1);

        rotation_2.rotZ(angle_2);
        rotationOfArm2.setTransform(rotation_2);

        translation_1.setTranslation(new Vector3d(0.0, 0.0,translation_3));
        translationOfGripper.setTransform(translation_1);
        
    }


    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyChar()=='d') {kay_d=true;}
        if (e.getKeyChar()=='a') {kay_a=true;}
        if (e.getKeyChar()=='w') {kay_w=true;}
        if (e.getKeyChar()=='s') {kay_s=true;}
        if (e.getKeyChar()=='q') {kay_q=true;}
        if (e.getKeyChar()=='e') {kay_e=true;}
        if (e.getKeyChar()=='g') {kay_g=true;}
        if (e.getKeyCode()==KeyEvent.VK_ENTER)
        {
            if(kay_enter_catch)kay_enter_catch = false;
            else kay_enter_catch=true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyChar()=='a') {kay_a=false;}
        if (e.getKeyChar()=='d') {kay_d=false;}
        if (e.getKeyChar()=='w') {kay_w=false;}
        if (e.getKeyChar()=='s') {kay_s=false;}
        if (e.getKeyChar()=='q') {kay_q=false;}
        if (e.getKeyChar()=='e') {kay_e=false;}
        if (e.getKeyChar()=='g') {kay_g=false;} //grabbing key
        if (e.getKeyCode()==KeyEvent.VK_ENTER) kay_enter_catch = false;
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }
    
}
