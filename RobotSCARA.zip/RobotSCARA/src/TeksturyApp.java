

import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.geometry.Box;
import com.sun.j3d.utils.image.TextureLoader;
import javax.media.j3d.*;
import javax.swing.*;
import java.awt.*;
import com.sun.j3d.utils.universe.SimpleUniverse;
import javax.media.j3d.Transform3D;
import javax.vecmath.Color3f;
import javax.vecmath.Point2f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

public class TeksturyApp extends JFrame{

    TeksturyApp(){
        super("Grafika 3D");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);


        GraphicsConfiguration config =
           SimpleUniverse.getPreferredConfiguration();

        Canvas3D canvas3D = new Canvas3D(config);
        canvas3D.setPreferredSize(new Dimension(800,600));

        add(canvas3D);
        pack();
        setVisible(true);

        BranchGroup scena = utworzScene();
	    scena.compile();
            setLocationRelativeTo(null);

        SimpleUniverse simpleU = new SimpleUniverse(canvas3D);

        Transform3D przesuniecie_obserwatora = new Transform3D();
        Transform3D rot_obs = new Transform3D();
        rot_obs.rotY((float)(-Math.PI/7));
        przesuniecie_obserwatora.set(new Vector3f(-1.2f,1.5f,2.0f));
        przesuniecie_obserwatora.mul(rot_obs);
        rot_obs.rotX((float)(-Math.PI/6));
        przesuniecie_obserwatora.mul(rot_obs);

        simpleU.getViewingPlatform().getViewPlatformTransform().setTransform(przesuniecie_obserwatora);

        simpleU.addBranchGraph(scena);
        
        OrbitBehavior orbit = new OrbitBehavior(canvas3D, OrbitBehavior.REVERSE_ROTATE);
        orbit.setSchedulingBounds(new BoundingSphere());
        simpleU.getViewingPlatform().setViewPlatformBehavior(orbit);

    }

    public BranchGroup utworzScene() 
    {

        int i;
        
        

        
        BranchGroup wezel_scena = new BranchGroup();

        Appearance wyglad_ziemia = new Appearance();
        Appearance wyglad_mury   = new Appearance();
        Appearance wyglad_daszek = new Appearance();
        Appearance wyglad_ogrodzenia = new Appearance();
        Appearance wyglad_kuli = new Appearance();
        

//        Material wmaterial_daszek = new Material(new Color3f(0.0f, 0.1f,0.0f), new Color3f(0.3f,0.0f,0.3f),
//                                             new Color3f(0.6f, 0.1f, 0.1f), new Color3f(1.0f, 0.5f, 0.5f), 80.0f);
//        wyglad_daszek.setMaterial(wmaterial_daszek);

        TextureLoader loader = new TextureLoader("obrazki/trawka.jpg",null);
        ImageComponent2D image = loader.getImage();

        Texture2D trawka = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA,
                                        image.getWidth(), image.getHeight());

        trawka.setImage(0, image);
        trawka.setBoundaryModeS(Texture.WRAP);
        trawka.setBoundaryModeT(Texture.WRAP);

        loader = new TextureLoader("obrazki/dachowka1.jpg",this);
        image = loader.getImage();

        Texture2D daszek = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA,
                                        image.getWidth(), image.getHeight());
        daszek.setImage(0, image);
        daszek.setBoundaryModeS(Texture.WRAP);
        daszek.setBoundaryModeT(Texture.WRAP);
        

        loader = new TextureLoader("obrazki/murek.jpg",this);
        image = loader.getImage();

        Texture2D murek = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA,
                                        image.getWidth(), image.getHeight());
        murek.setImage(0, image);
        murek.setBoundaryModeS(Texture.WRAP);
        murek.setBoundaryModeT(Texture.WRAP);
        
        loader = new TextureLoader("obrazki/cegla.jpg",this);
        image = loader.getImage();

        Texture2D ogrodzenie = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA,
                                        image.getWidth(), image.getHeight());
        ogrodzenie.setImage(0, image);
        ogrodzenie.setBoundaryModeS(Texture.WRAP);
        ogrodzenie.setBoundaryModeT(Texture.WRAP);
        
        loader = new TextureLoader("obrazki/default.jpg",this);
        image = loader.getImage();

        Texture2D chmury = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA,
                                        image.getWidth(), image.getHeight());
        chmury.setImage(0, image);
        chmury.setBoundaryModeS(Texture.WRAP);
        chmury.setBoundaryModeT(Texture.WRAP);
        
       



        BoundingSphere bounds = new BoundingSphere();
        AmbientLight lightA = new AmbientLight();
        lightA.setInfluencingBounds(bounds);
        wezel_scena.addChild(lightA);

        DirectionalLight lightD = new DirectionalLight();
        lightD.setInfluencingBounds(bounds);
        lightD.setDirection(new Vector3f(0.0f, 0.0f, -1.0f));
        lightD.setColor(new Color3f(1.0f, 1.0f, 1.0f));
        wezel_scena.addChild(lightD);


        wyglad_ziemia.setTexture(trawka);
        wyglad_mury.setTexture(murek);
        wyglad_ogrodzenia.setTexture(ogrodzenie);
        wyglad_kuli.setTexture(chmury);
        wyglad_daszek.setTexture(daszek);
        
        Point3f[]  coords = new Point3f[4];
        for(i = 0; i< 4; i++)
            coords[i] = new Point3f();

        Point2f[]  tex_coords = new Point2f[4];
        for(i = 0; i< 4; i++)
            tex_coords[i] = new Point2f();

        coords[0].y = 0.0f;
        coords[1].y = 0.0f;
        coords[2].y = 0.0f;
        coords[3].y = 0.0f;

        coords[0].x = 0.5f;
        coords[1].x = 0.5f;
        coords[2].x = -0.5f;
        coords[3].x = -0.5f;

        coords[0].z = 0.5f;
        coords[1].z = -0.5f;
        coords[2].z = -0.5f;
        coords[3].z = 0.5f;

        tex_coords[0].x = 0.0f;
        tex_coords[0].y = 0.0f;

        tex_coords[1].x = 10.0f;
        tex_coords[1].y = 0.0f;

        tex_coords[2].x = 0.0f;
        tex_coords[2].y = 10.0f;

        tex_coords[3].x = 10.0f;
        tex_coords[3].y = 10.0f;


        //ziemia

        QuadArray qa_ziemia = new QuadArray(4, GeometryArray.COORDINATES| GeometryArray.TEXTURE_COORDINATE_3);
        qa_ziemia.setCoordinates(0,coords);

        qa_ziemia.setTextureCoordinates(0, tex_coords);


        Shape3D ziemia = new Shape3D(qa_ziemia);
        ziemia.setAppearance(wyglad_ziemia);

        wezel_scena.addChild(ziemia);


        //wieza


        TransformGroup wieza_p = new TransformGroup();
        Transform3D przesuniecie_wiezy = new Transform3D();
        przesuniecie_wiezy.set(new Vector3f(0.0f,0.3f,0.0f));
        wieza_p.setTransform(przesuniecie_wiezy);

        Cylinder walec = new Cylinder(0.2f,0.6f,Cylinder.GENERATE_NORMALS| Cylinder.GENERATE_TEXTURE_COORDS, wyglad_mury);

        wieza_p.addChild(walec);
        wezel_scena.addChild(wieza_p);


        TransformGroup daszek_p = new TransformGroup();
        Transform3D przesuniecie_daszka = new Transform3D();
        przesuniecie_daszka.set(new Vector3f(0.0f,0.7f,0.0f));
        daszek_p.setTransform(przesuniecie_daszka);

        Cone daszek1 = new Cone(0.25f,0.2f,Cone.GENERATE_NORMALS|Cone.GENERATE_TEXTURE_COORDS, wyglad_daszek);

        daszek_p.addChild(daszek1);
        wezel_scena.addChild(daszek_p);
        
        //murek
        
        TransformGroup murek_p = new TransformGroup();
        Transform3D przesuniecie_murka = new Transform3D();
        przesuniecie_murka.set(new Vector3f(0.0f,0.067f,0.4f));
        murek_p.setTransform(przesuniecie_murka);   
        Box mur1 = new Box(0.4f, 0.07f, 0.01f, Box.GENERATE_NORMALS| Box.GENERATE_TEXTURE_COORDS, wyglad_ogrodzenia);    
        murek_p.addChild(mur1);
        
        
        TransformGroup murek_p1 = new TransformGroup();
        Transform3D przesuniecie_murka1 = new Transform3D();
        przesuniecie_murka1.set(new Vector3f(0.0f,0.067f,-0.4f));
        murek_p1.setTransform(przesuniecie_murka1);     
        Box mur2 = new Box(0.4f, 0.07f, 0.01f, Box.GENERATE_NORMALS| Box.GENERATE_TEXTURE_COORDS, wyglad_ogrodzenia);  
        murek_p1.addChild(mur2);
        
        
        
         
        TransformGroup murek_p2 = new TransformGroup();
        Transform3D przesuniecie_murka2 = new Transform3D();
        przesuniecie_murka2.set(new Vector3f(-0.4f,0.067f,0.0f));
        murek_p2.setTransform(przesuniecie_murka2);   
        Box mur3 = new Box(0.01f, 0.07f, 0.41f, Box.GENERATE_NORMALS| Box.GENERATE_TEXTURE_COORDS, wyglad_ogrodzenia);
        murek_p2.addChild(mur3);
        
        
        
        TransformGroup murek_p3 = new TransformGroup();
        Transform3D przesuniecie_murka3 = new Transform3D();
        przesuniecie_murka3.set(new Vector3f(0.4f,0.067f,0.0f));
        murek_p3.setTransform(przesuniecie_murka3);   
        Box mur4 = new Box(0.01f, 0.07f, 0.41f, Box.GENERATE_NORMALS| Box.GENERATE_TEXTURE_COORDS, wyglad_ogrodzenia);
        murek_p3.addChild(mur4);
        
        TransformGroup duzy_mur = new TransformGroup();

        duzy_mur.addChild(murek_p);
        duzy_mur.addChild(murek_p1);
        duzy_mur.addChild(murek_p2);
        duzy_mur.addChild(murek_p3);
       
        wezel_scena.addChild(duzy_mur);
        
//        wezel_scena.addChild(murek_p);
//        wezel_scena.addChild(murek_p1);
//        wezel_scena.addChild(murek_p2);
//        wezel_scena.addChild(murek_p3);
        
        //chmury
        
        Sphere kula = new Sphere(3f, Sphere.GENERATE_NORMALS_INWARD| Sphere.GENERATE_TEXTURE_COORDS, wyglad_kuli);
        wezel_scena.addChild(kula);
            

        



        return wezel_scena;


    }

    public static void main(String args[]){
      new TeksturyApp();

   }

}
