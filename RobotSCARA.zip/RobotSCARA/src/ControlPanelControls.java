/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
//import javax.swing.JRadioButton;

/**
 *
 * @author Michał
 */
public class ControlPanelControls extends JPanel implements ActionListener {
    
    String START_ACTION_BUTTON = "Strat";
    String STOP_ACTION_BUTTON = "Stop";
    String NAME_OF_BUTTONS = "Działanie Robota SCARA";
    protected JButton startbutton, stopbutton;
    
    public JPanel controlPanel()
    {
        JPanel emptyControlPanel = new JPanel();
        JPanel controlPanel = new JPanel(new GridLayout(1, 3));
                
        // Tworzenie kontrolnego panelu
        
        controlPanel.setBackground(Color.white); 
        Border paneEdge = BorderFactory.createEmptyBorder(0,10,10,10);
        TitledBorder titleOfPanel = BorderFactory.createTitledBorder(NAME_OF_BUTTONS);
        controlPanel.setBorder(paneEdge);
        
        //TitledBorder titleOfPanel = BorderFactory.createTitledBorder(NAME_OF_BUTTONS);
        
        emptyControlPanel.setBorder(paneEdge);
        emptyControlPanel.add(controlPanel);
        controlPanel.setBorder(titleOfPanel);
        emptyControlPanel.setPreferredSize(new Dimension(200, 190));
        
        
        
        
        // Tworzenie guziczków do panelu
        
        stopbutton = new JButton(STOP_ACTION_BUTTON);
        stopbutton.setVerticalTextPosition(AbstractButton.CENTER);
        stopbutton.setHorizontalTextPosition(AbstractButton.LEADING); //aka LEFT, for left-to-right locales
        stopbutton.setMnemonic(KeyEvent.VK_D);
        stopbutton.setActionCommand("disable");
        stopbutton.setEnabled(false);
        
        startbutton = new JButton(START_ACTION_BUTTON);
        startbutton.setVerticalTextPosition(AbstractButton.CENTER);
        startbutton.setHorizontalTextPosition(AbstractButton.LEADING); //aka LEFT, for left-to-right locales
        startbutton.setMnemonic(KeyEvent.VK_E);
        startbutton.setActionCommand("enable");
        startbutton.setEnabled(false);
        
        // Pokazuje napisy gdy najedzie się na guziki
        startbutton.setToolTipText("Naciśnij aby włączyć robota typu SCARA.");
        stopbutton.setToolTipText("Naciśnij aby wyłączyć robota typu SCARA.");
        
        startbutton.addActionListener(this);
        stopbutton.addActionListener(this);
              
        ButtonGroup controlActionGroup = new ButtonGroup();
        controlActionGroup.add(stopbutton);
        controlActionGroup.add(startbutton);
        
        controlPanel.add(stopbutton);
        controlPanel.add(startbutton);
        
        return controlPanel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if ("enable".equals(e.getActionCommand())) {
            startbutton.setEnabled(false);
            stopbutton.setEnabled(true);
        } else {
            startbutton.setEnabled(true);
            stopbutton.setEnabled(false);
        }
        }
    }
