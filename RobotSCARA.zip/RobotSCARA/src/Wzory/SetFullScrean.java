/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Wzory;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.*;
import javax.swing.*;

public class SetFullScrean extends JFrame {
    
    
    private JPanel contentPane = new JPanel();
    private JButton fullscreenButton = new JButton("Fullscreen Mode");
    private boolean Am_I_In_FullScreen = false;
    private int PrevX, PrevY, PrevWidth, PrevHeight;


    public SetFullScrean() {

        // From Here starts the trick
        FullScreenEffect effect = new FullScreenEffect();

        fullscreenButton.addActionListener(effect);
        contentPane.add(fullscreenButton);
        fullscreenButton.setVisible(true);
        
    }

    private class FullScreenEffect implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent arg0) {
            if (Am_I_In_FullScreen == false) {
                PrevX = getX();
                PrevY = getY();
                PrevWidth = getWidth();
                PrevHeight = getHeight();

                // Destroys the whole JFrame but keeps organized every Component
                // Needed if you want to use Undecorated JFrame dispose() is the
                // reason that this trick doesn't work with videos.
                dispose();
                setUndecorated(true);

                setBounds(0, 0, getToolkit().getScreenSize().width,
                        getToolkit().getScreenSize().height);
                setVisible(true);
                Am_I_In_FullScreen = true;
            } else {
                setVisible(true);
                setBounds(PrevX, PrevY, PrevWidth, PrevHeight);
                dispose();
                setUndecorated(false);
                setVisible(true);
                Am_I_In_FullScreen = false;
            }
        }
    }
}