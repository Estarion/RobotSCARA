/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robotscara;

import javax.media.j3d.Transform3D;

/**
 *
 * @author Michał
 */
public class ObjectClass {

    boolean picked = false;
    boolean activeKay = false;
    Transform3D position = new Transform3D();
    
    ObjectClass(boolean picked,  boolean activeKay, Transform3D position)
    {
        this.picked = picked;
        this.activeKay = activeKay;
        this.position = position;
    }
    ObjectClass(){
        
    }
    boolean getPicked(){ return picked; }
    boolean getActiveKay(){ return activeKay; }
    Transform3D getPosition(){ return position; }
    
    void setPicked(boolean picked){ this.picked = picked; }
    void setActiveKay(boolean activeKay){ this.activeKay = activeKay; }
    void setPosition(Transform3D position){ this.position = position; }
}
